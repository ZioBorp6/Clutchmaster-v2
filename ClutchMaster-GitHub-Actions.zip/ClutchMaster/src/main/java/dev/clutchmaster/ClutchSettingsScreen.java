package dev.clutchmaster;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class ClutchSettingsScreen extends Screen {
    private final Screen parent;

    public ClutchSettingsScreen(Screen parent) {
        super(Text.translatable("screen.clutchmaster.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int columnWidth = Math.min(174, (this.width - 24) / 2);
        int gap = 6;
        int totalWidth = columnWidth * 2 + gap;
        int left = (this.width - totalWidth) / 2;
        int right = left + columnWidth + gap;
        int top = 30;
        int rowHeight = 18;

        addToggle(left, top, columnWidth, "Auto MLG", ClutchConfig.CONFIG.enabled,
                () -> ClutchConfig.CONFIG.enabled = !ClutchConfig.CONFIG.enabled);
        addToggle(right, top, columnWidth, "Camera aim", ClutchConfig.CONFIG.autoCameraAim,
                () -> ClutchConfig.CONFIG.autoCameraAim = !ClutchConfig.CONFIG.autoCameraAim);

        addToggle(left, top + rowHeight, columnWidth, "Water bucket", ClutchConfig.CONFIG.waterBucket,
                () -> ClutchConfig.CONFIG.waterBucket = !ClutchConfig.CONFIG.waterBucket);
        addToggle(right, top + rowHeight, columnWidth, "Powder snow", ClutchConfig.CONFIG.powderSnowBucket,
                () -> ClutchConfig.CONFIG.powderSnowBucket = !ClutchConfig.CONFIG.powderSnowBucket);

        addToggle(left, top + rowHeight * 2, columnWidth, "Slime block", ClutchConfig.CONFIG.slimeBlock,
                () -> ClutchConfig.CONFIG.slimeBlock = !ClutchConfig.CONFIG.slimeBlock);
        addToggle(right, top + rowHeight * 2, columnWidth, "Hay bale", ClutchConfig.CONFIG.hayBale,
                () -> ClutchConfig.CONFIG.hayBale = !ClutchConfig.CONFIG.hayBale);

        addToggle(left, top + rowHeight * 3, columnWidth, "Cobweb", ClutchConfig.CONFIG.cobweb,
                () -> ClutchConfig.CONFIG.cobweb = !ClutchConfig.CONFIG.cobweb);
        addToggle(right, top + rowHeight * 3, columnWidth, "Boat", ClutchConfig.CONFIG.boat,
                () -> ClutchConfig.CONFIG.boat = !ClutchConfig.CONFIG.boat);

        addToggle(left, top + rowHeight * 4, columnWidth, "Scan all hotbar slots", ClutchConfig.CONFIG.scanWholeHotbar,
                () -> ClutchConfig.CONFIG.scanWholeHotbar = !ClutchConfig.CONFIG.scanWholeHotbar);
        addToggle(right, top + rowHeight * 4, columnWidth, "Restore old slot", ClutchConfig.CONFIG.restoreHotbarSlot,
                () -> ClutchConfig.CONFIG.restoreHotbarSlot = !ClutchConfig.CONFIG.restoreHotbarSlot);

        addToggle(left, top + rowHeight * 5, columnWidth, "Restore camera", ClutchConfig.CONFIG.restoreCamera,
                () -> ClutchConfig.CONFIG.restoreCamera = !ClutchConfig.CONFIG.restoreCamera);
        addButton(right, top + rowHeight * 5, columnWidth,
                "Attempts per fall: " + ClutchConfig.CONFIG.maxAttemptsPerFall,
                () -> {
                    ClutchConfig.CONFIG.maxAttemptsPerFall = ClutchConfig.CONFIG.maxAttemptsPerFall % 3 + 1;
                    saveAndRefresh();
                });

        addButton(left, top + rowHeight * 6, columnWidth, "Aim speed  −", () -> adjustSpeed(-1.0f));
        addButton(right, top + rowHeight * 6, columnWidth, "Aim speed  +", () -> adjustSpeed(1.0f));
        addButton(left, top + rowHeight * 7, columnWidth, "Fall threshold  −", () -> adjustSensitivity(-0.05f));
        addButton(right, top + rowHeight * 7, columnWidth, "Fall threshold  +", () -> adjustSensitivity(0.05f));
        addButton(left, top + rowHeight * 8, columnWidth, "Aim starts closer", () -> adjustAimDistance(-2.0f));
        addButton(right, top + rowHeight * 8, columnWidth, "Aim starts earlier", () -> adjustAimDistance(2.0f));

        addButton(left, top + rowHeight * 9, totalWidth, priorityLabel(), () -> {
            var order = ClutchConfig.CONFIG.clutchPriority;
            if (order.size() > 1) order.add(order.remove(0));
            saveAndRefresh();
        });
        addButton(left, top + rowHeight * 10, totalWidth, "Done", () -> close());
    }

    private void addToggle(int x, int y, int width, String label, boolean value, Runnable action) {
        addButton(x, y, width, label + ": " + (value ? "ON" : "OFF"), () -> {
            action.run();
            saveAndRefresh();
        });
    }

    private void addButton(int x, int y, int width, String label, Runnable action) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label), button -> action.run())
                .dimensions(x, y, width, 17).build());
    }

    private String priorityLabel() {
        String first = ClutchConfig.CONFIG.clutchPriority.isEmpty()
                ? "Water Bucket" : ClutchConfig.CONFIG.clutchPriority.get(0).replace('_', ' ');
        return "Priority first: " + first + " (tap to rotate)";
    }

    private void adjustSpeed(float amount) {
        ClutchConfig.CONFIG.cameraRotationSpeed = clamp(ClutchConfig.CONFIG.cameraRotationSpeed + amount, 1.0f, 30.0f);
        saveAndRefresh();
    }

    private void adjustSensitivity(float amount) {
        ClutchConfig.CONFIG.fallDetectionSensitivity = clamp(ClutchConfig.CONFIG.fallDetectionSensitivity + amount, 0.08f, 1.20f);
        saveAndRefresh();
    }

    private void adjustAimDistance(float amount) {
        ClutchConfig.CONFIG.aimStartDistance = clamp(ClutchConfig.CONFIG.aimStartDistance + amount, 5.0f, 48.0f);
        saveAndRefresh();
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private void saveAndRefresh() {
        ClutchConfig.save();
        clearAndInit();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 8, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal(String.format("Aim %.0f°/tick  |  Fall %.2f  |  Aim from %.0f blocks",
                        ClutchConfig.CONFIG.cameraRotationSpeed,
                        ClutchConfig.CONFIG.fallDetectionSensitivity,
                        ClutchConfig.CONFIG.aimStartDistance)),
                width / 2, 17, 0xCCCCCC);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Keys: G = toggle, H = settings (rebind in Controls)"),
                width / 2, 24, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        ClutchConfig.save();
        if (client != null) client.setScreen(parent);
    }
}
