package dev.clutchmaster;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class ClutchConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("clutchmaster.json");
    public static Settings CONFIG = new Settings();

    private ClutchConfig() {}

    public static void load() {
        if (!Files.exists(FILE)) {
            save();
            return;
        }
        try {
            Settings loaded = GSON.fromJson(Files.readString(FILE), Settings.class);
            if (loaded != null) CONFIG = loaded;
            CONFIG.normalize();
        } catch (Exception exception) {
            System.err.println("[ClutchMaster] Invalid config; defaults loaded: " + exception.getMessage());
            CONFIG = new Settings();
            save();
        }
    }

    public static void save() {
        CONFIG.normalize();
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(CONFIG));
        } catch (IOException exception) {
            System.err.println("[ClutchMaster] Could not save config: " + exception.getMessage());
        }
    }

    public static final class Settings {
        public boolean enabled = false;
        public boolean autoCameraAim = true;
        public boolean scanWholeHotbar = true;
        public boolean restoreHotbarSlot = true;
        public boolean restoreCamera = true;

        public boolean waterBucket = true;
        public boolean powderSnowBucket = true;
        public boolean slimeBlock = true;
        public boolean hayBale = true;
        public boolean cobweb = true;
        public boolean boat = true;

        /** Maximum camera turn per client tick, in degrees. */
        public float cameraRotationSpeed = 12.0f;
        /** Minimum downward velocity magnitude before a fall is tracked. */
        public float fallDetectionSensitivity = 0.30f;
        /** Start steering once this much vertical distance remains to the landing surface. */
        public float aimStartDistance = 18.0f;
        /** Maximum number of attempts during one fall. */
        public int maxAttemptsPerFall = 2;
        /** Ordered clutch type IDs, highest priority first. */
        public List<String> clutchPriority = new ArrayList<>(List.of(
                "WATER_BUCKET", "POWDER_SNOW_BUCKET", "SLIME_BLOCK",
                "HAY_BALE", "COBWEB", "BOAT"
        ));

        private void normalize() {
            cameraRotationSpeed = clamp(cameraRotationSpeed, 1.0f, 30.0f);
            fallDetectionSensitivity = clamp(fallDetectionSensitivity, 0.08f, 1.20f);
            aimStartDistance = clamp(aimStartDistance, 5.0f, 48.0f);
            maxAttemptsPerFall = Math.max(1, Math.min(3, maxAttemptsPerFall));

            if (clutchPriority == null) clutchPriority = new ArrayList<>();
            List<String> cleaned = new ArrayList<>();
            for (String value : clutchPriority) {
                if (value == null) continue;
                try {
                    ClutchController.ClutchType.valueOf(value);
                    if (!cleaned.contains(value)) cleaned.add(value);
                } catch (IllegalArgumentException ignored) {
                    // Ignore unknown values from hand-edited configuration files.
                }
            }
            for (ClutchController.ClutchType type : ClutchController.ClutchType.values()) {
                if (!cleaned.contains(type.name())) cleaned.add(type.name());
            }
            clutchPriority = cleaned;
        }

        private static float clamp(float value, float min, float max) {
            return Math.max(min, Math.min(max, value));
        }
    }
}
