package dev.clutchmaster;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Predictive, client-side clutch helper. All actions go through the normal
 * ClientPlayerInteractionManager; the server remains authoritative.
 */
public final class ClutchController {
    public enum ClutchType {
        WATER_BUCKET("Water Bucket", Items.WATER_BUCKET, Mode.BLOCK_USE),
        POWDER_SNOW_BUCKET("Powder Snow", Items.POWDER_SNOW_BUCKET, Mode.BLOCK_USE),
        SLIME_BLOCK("Slime Block", Items.SLIME_BLOCK, Mode.BLOCK_USE),
        HAY_BALE("Hay Bale", Items.HAY_BLOCK, Mode.BLOCK_USE),
        COBWEB("Cobweb", Items.COBWEB, Mode.BLOCK_USE),
        BOAT("Boat", Items.OAK_BOAT, Mode.ITEM_USE);

        final String displayName;
        final Item item;
        final Mode mode;

        ClutchType(String displayName, Item item, Mode mode) {
            this.displayName = displayName;
            this.item = item;
            this.mode = mode;
        }
    }

    private enum Mode { BLOCK_USE, ITEM_USE }
    private enum Phase { IDLE, TRACKING, BOAT_MOUNT, RESTORING }
    private static final double GRAVITY_PER_TICK = 0.08;
    private static final double HORIZONTAL_DRAG = 0.91;

    private static Phase phase = Phase.IDLE;
    private static ClutchType chosen;
    private static final List<ClutchType> rejectedTypes = new ArrayList<>();
    private static BlockHitResult groundHit;
    private static float savedYaw;
    private static float savedPitch;
    private static int savedSlot = -1;
    private static int attemptCount;
    private static int restoreTicks;
    private static long tickCount;
    private static long nextAttemptTick;
    private static String hudStatus = "";

    private ClutchController() {}

    public static void onToggled(MinecraftClient client, boolean enabled) {
        if (!enabled) reset(client, true);
        hudStatus = "";
    }

    public static String getHudStatus() {
        return hudStatus;
    }

    public static void tick(MinecraftClient client) {
        tickCount++;
        if (client.player == null || client.world == null || client.interactionManager == null) {
            reset(client, false);
            hudStatus = "";
            return;
        }

        if (!ClutchConfig.CONFIG.enabled || client.currentScreen != null) {
            if (phase != Phase.IDLE) reset(client, true);
            return;
        }

        switch (phase) {
            case IDLE -> detectFall(client);
            case TRACKING -> trackAndAttempt(client);
            case BOAT_MOUNT -> mountPlacedBoat(client);
            case RESTORING -> restorePlayer(client);
        }
    }

    private static void detectFall(MinecraftClient client) {
        var player = client.player;
        if (player.isOnGround() || player.isFallFlying() || player.isTouchingWater()
                || player.getAbilities().flying || player.isClimbing() || player.isSpectator()
                || player.hasVehicle() || player.getVelocity().y >= -ClutchConfig.CONFIG.fallDetectionSensitivity) {
            return;
        }

        BlockHitResult ground = raycastLandingSurface(client, player.getX(), player.getZ());
        if (ground == null) return;

        double verticalDistance = player.getY() - ground.getPos().y;
        if (verticalDistance <= 0.0) return;
        // Track only falls that are likely to exceed the vanilla fall-damage threshold.
        if (player.fallDistance + verticalDistance < 3.5) return;

        ClutchType available = findBestAvailable(player.getInventory());
        if (available == null) {
            hudStatus = "No enabled clutch item in hotbar";
            return;
        }

        savedYaw = player.getYaw();
        savedPitch = player.getPitch();
        savedSlot = player.getInventory().selectedSlot;
        chosen = available;
        rejectedTypes.clear();
        groundHit = ground;
        attemptCount = 0;
        nextAttemptTick = tickCount;
        phase = Phase.TRACKING;
        hudStatus = "Tracking fall: " + chosen.displayName;
    }

    private static void trackAndAttempt(MinecraftClient client) {
        var player = client.player;
        if (player.isOnGround() || player.getVelocity().y >= 0.0 || player.isTouchingWater()) {
            beginRestore();
            return;
        }

        PredictedTarget prediction = predictLanding(client);
        if (prediction == null) {
            hudStatus = "Landing surface not found";
            beginRestore();
            return;
        }
        groundHit = prediction.hit;

        if (ClutchConfig.CONFIG.autoCameraAim) {
            aimAt(player, groundHit.getPos());
        }

        hudStatus = String.format("Aiming: %s  |  %.1f blocks", chosen.displayName, prediction.verticalDistance);

        if (prediction.verticalDistance > ClutchConfig.CONFIG.aimStartDistance
                && player.fallDistance + prediction.verticalDistance < 4.0) {
            return;
        }

        double reach = Math.max(2.5, client.interactionManager.getReachDistance() - 0.20);
        double eyeDistance = player.getCameraPosVec(1.0f).distanceTo(groundHit.getPos());
        boolean inReach = eyeDistance <= reach;
        boolean imminent = prediction.timeToImpactTicks <= 4.0;

        if (inReach && imminent && tickCount >= nextAttemptTick) {
            attempt(client);
        }

        if (prediction.timeToImpactTicks <= 0.15 || prediction.verticalDistance < 0.45) {
            beginRestore();
        }
    }

    private static PredictedTarget predictLanding(MinecraftClient client) {
        var player = client.player;
        BlockHitResult current = raycastLandingSurface(client, player.getX(), player.getZ());
        if (current == null) return null;

        double currentDistance = Math.max(0.0, player.getY() - current.getPos().y);
        double downwardSpeed = Math.max(0.0, -player.getVelocity().y);
        double ticks = estimateFallTicks(currentDistance, downwardSpeed);
        double predictedX = player.getX() + integratedHorizontal(player.getVelocity().x, ticks);
        double predictedZ = player.getZ() + integratedHorizontal(player.getVelocity().z, ticks);

        BlockHitResult predicted = raycastLandingSurface(client, predictedX, predictedZ);
        if (predicted == null) predicted = current;

        double distance = Math.max(0.0, player.getY() - predicted.getPos().y);
        double time = estimateFallTicks(distance, downwardSpeed);
        return new PredictedTarget(predicted, distance, time);
    }

    private static double estimateFallTicks(double distance, double downwardSpeed) {
        if (distance <= 0.0) return 0.0;
        // Solve distance = v*t + 0.5*g*t^2 using the game's approximate per-tick gravity.
        double discriminant = downwardSpeed * downwardSpeed + 2.0 * GRAVITY_PER_TICK * distance;
        return (-downwardSpeed + Math.sqrt(discriminant)) / GRAVITY_PER_TICK;
    }

    private static double integratedHorizontal(double velocity, double ticks) {
        if (ticks <= 0.0) return 0.0;
        double dragPower = Math.pow(HORIZONTAL_DRAG, ticks);
        return velocity * (1.0 - dragPower) / (1.0 - HORIZONTAL_DRAG);
    }

    private static BlockHitResult raycastLandingSurface(MinecraftClient client, double x, double z) {
        var player = client.player;
        Vec3d start = new Vec3d(x, player.getY() + 0.25, z);
        Vec3d end = new Vec3d(x, Math.max(client.world.getBottomY(), player.getY() - 128.0), z);
        HitResult result = client.world.raycast(new RaycastContext(
                start, end,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                player
        ));
        if (result.getType() != HitResult.Type.BLOCK) return null;
        BlockHitResult hit = (BlockHitResult) result;
        // A downward landing ray must hit the top face of a collidable block.
        if (hit.getSide() != Direction.UP) return null;
        return hit;
    }

    private static void attempt(MinecraftClient client) {
        var player = client.player;
        if (chosen == null || groundHit == null) {
            beginRestore();
            return;
        }
        if (attemptCount >= ClutchConfig.CONFIG.maxAttemptsPerFall) {
            beginRestore();
            return;
        }

        int slot = findSlot(player.getInventory(), chosen);
        if (slot < 0) {
            rejectCurrentAndSelectNext(client, "Item left the hotbar");
            return;
        }

        // Placeable clutch types need replaceable space above the support block.
        if (chosen != ClutchType.BOAT && !client.world.getBlockState(groundHit.getBlockPos().up()).isReplaceable()) {
            rejectCurrentAndSelectNext(client, "No clear placement space for " + chosen.displayName);
            return;
        }

        // Wait for the camera ray to reach the chosen support before changing slots
        // or sending an interaction. This reduces false targets and hotbar flicker.
        if (ClutchConfig.CONFIG.autoCameraAim) {
            HitResult viewHit = player.raycast(client.interactionManager.getReachDistance(), 1.0f, false);
            if (viewHit.getType() != HitResult.Type.BLOCK
                    || !((BlockHitResult) viewHit).getBlockPos().equals(groundHit.getBlockPos())) {
                nextAttemptTick = tickCount + 1;
                return;
            }
        }

        int previous = player.getInventory().selectedSlot;
        player.getInventory().selectedSlot = slot;
        ActionResult result;
        if (chosen.mode == Mode.ITEM_USE) {
            // BoatItem performs its own view raycast, so camera aim is mandatory.
            if (!ClutchConfig.CONFIG.autoCameraAim) {
                player.getInventory().selectedSlot = previous;
                hudStatus = "Boat clutch requires camera aim";
                beginRestore();
                return;
            }
            result = client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        } else {
            result = client.interactionManager.interactBlock(player, Hand.MAIN_HAND, groundHit);
        }
        attemptCount++;

        if (result.isAccepted()) {
            if (chosen == ClutchType.BOAT) {
                phase = Phase.BOAT_MOUNT;
                restoreTicks = 0;
                hudStatus = "Boat placed; attempting to mount";
            } else {
                hudStatus = "Clutch action sent: " + chosen.displayName;
                beginRestore();
            }
        } else {
            rejectCurrentAndSelectNext(client, "Interaction rejected: " + chosen.displayName);
        }
    }


    private static void rejectCurrentAndSelectNext(MinecraftClient client, String reason) {
        if (chosen != null && !rejectedTypes.contains(chosen)) rejectedTypes.add(chosen);
        ClutchType next = findBestAvailable(client.player.getInventory());
        if (next != null && attemptCount < ClutchConfig.CONFIG.maxAttemptsPerFall) {
            chosen = next;
            nextAttemptTick = tickCount + 1;
            hudStatus = reason + "; trying " + chosen.displayName;
        } else {
            hudStatus = reason;
            beginRestore();
        }
    }

    private static void mountPlacedBoat(MinecraftClient client) {
        var player = client.player;
        if (player == null || groundHit == null) {
            beginRestore();
            return;
        }
        if (player.hasVehicle()) {
            hudStatus = "Mounted boat";
            beginRestore();
            return;
        }

        restoreTicks++;
        Vec3d center = groundHit.getPos();
        Box searchBox = new Box(center.x - 2.5, center.y - 1.0, center.z - 2.5,
                center.x + 2.5, center.y + 2.0, center.z + 2.5);
        BoatEntity boat = client.world.getEntitiesByClass(BoatEntity.class, searchBox,
                entity -> entity.isAlive() && entity.squaredDistanceTo(player) <= 25.0)
                .stream()
                .min((a, b) -> Double.compare(a.squaredDistanceTo(player), b.squaredDistanceTo(player)))
                .orElse(null);

        if (boat != null) {
            ActionResult mountResult = client.interactionManager.interactEntity(player, boat, Hand.MAIN_HAND);
            if (mountResult.isAccepted()) {
                hudStatus = "Boat mount interaction sent";
                beginRestore();
                return;
            }
        }
        if (restoreTicks >= 3) {
            hudStatus = "Boat placed; mount was not confirmed";
            beginRestore();
        }
    }

    private static void aimAt(net.minecraft.client.network.ClientPlayerEntity player, Vec3d destination) {
        Vec3d eyes = player.getCameraPosVec(1.0f);
        Vec3d delta = destination.subtract(eyes);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float desiredPitch = (float) (-(MathHelper.atan2(delta.y, horizontal) * 57.2957763671875));
        float speed = ClutchConfig.CONFIG.cameraRotationSpeed;
        // When the landing point is almost directly below, yaw has no effect on aiming.
        if (horizontal > 0.10) {
            float desiredYaw = (float) (MathHelper.atan2(delta.z, delta.x) * 57.2957763671875) - 90.0f;
            player.setYaw(approachAngle(player.getYaw(), desiredYaw, speed));
        }
        player.setPitch(MathHelper.clamp(approach(player.getPitch(), desiredPitch, speed), -90.0f, 90.0f));
    }

    private static float approachAngle(float current, float target, float maxStep) {
        float difference = MathHelper.wrapDegrees(target - current);
        return current + MathHelper.clamp(difference, -maxStep, maxStep);
    }

    private static float approach(float current, float target, float maxStep) {
        return current + MathHelper.clamp(target - current, -maxStep, maxStep);
    }

    private static void beginRestore() {
        phase = Phase.RESTORING;
        restoreTicks = 0;
    }

    private static void restorePlayer(MinecraftClient client) {
        var player = client.player;
        if (player == null) {
            reset(client, false);
            return;
        }
        restoreTicks++;
        if (ClutchConfig.CONFIG.restoreCamera) {
            float speed = ClutchConfig.CONFIG.cameraRotationSpeed;
            player.setYaw(approachAngle(player.getYaw(), savedYaw, speed));
            player.setPitch(approach(player.getPitch(), savedPitch, speed));
        }
        boolean cameraDone = !ClutchConfig.CONFIG.restoreCamera
                || (Math.abs(MathHelper.wrapDegrees(savedYaw - player.getYaw())) < 0.75f
                && Math.abs(savedPitch - player.getPitch()) < 0.75f);
        if ((restoreTicks >= 1 && cameraDone) || restoreTicks >= 24) {
            if (ClutchConfig.CONFIG.restoreCamera) {
                player.setYaw(savedYaw);
                player.setPitch(savedPitch);
            }
            if (ClutchConfig.CONFIG.restoreHotbarSlot && savedSlot >= 0 && savedSlot < 9) {
                player.getInventory().selectedSlot = savedSlot;
            }
            phase = Phase.IDLE;
            chosen = null;
            groundHit = null;
            savedSlot = -1;
            attemptCount = 0;
            rejectedTypes.clear();
            hudStatus = "";
        }
    }

    private static ClutchType findBestAvailable(PlayerInventory inventory) {
        for (String name : ClutchConfig.CONFIG.clutchPriority) {
            try {
                ClutchType type = ClutchType.valueOf(name);
                if (isEnabled(type) && !rejectedTypes.contains(type) && findSlot(inventory, type) >= 0) return type;
            } catch (IllegalArgumentException ignored) {
                // Ignore invalid values in manually edited JSON.
            }
        }
        return null;
    }

    private static boolean isEnabled(ClutchType type) {
        var config = ClutchConfig.CONFIG;
        return switch (type) {
            case WATER_BUCKET -> config.waterBucket;
            case POWDER_SNOW_BUCKET -> config.powderSnowBucket;
            case SLIME_BLOCK -> config.slimeBlock;
            case HAY_BALE -> config.hayBale;
            case COBWEB -> config.cobweb;
            case BOAT -> config.boat && config.autoCameraAim;
        };
    }

    private static int findSlot(PlayerInventory inventory, ClutchType type) {
        int start = ClutchConfig.CONFIG.scanWholeHotbar ? 0 : inventory.selectedSlot;
        int end = ClutchConfig.CONFIG.scanWholeHotbar ? 9 : inventory.selectedSlot + 1;
        for (int slot = start; slot < end; slot++) {
            var stack = inventory.getStack(slot);
            if (type == ClutchType.BOAT) {
                for (Item item : boatItems()) if (stack.isOf(item)) return slot;
            } else if (stack.isOf(type.item)) {
                return slot;
            }
        }
        return -1;
    }

    private static List<Item> boatItems() {
        List<Item> boats = new ArrayList<>();
        boats.add(Items.OAK_BOAT);
        boats.add(Items.SPRUCE_BOAT);
        boats.add(Items.BIRCH_BOAT);
        boats.add(Items.JUNGLE_BOAT);
        boats.add(Items.ACACIA_BOAT);
        boats.add(Items.DARK_OAK_BOAT);
        boats.add(Items.MANGROVE_BOAT);
        boats.add(Items.BAMBOO_RAFT);
        return boats;
    }

    private static void reset(MinecraftClient client, boolean restore) {
        if (restore && client.player != null) {
            if (ClutchConfig.CONFIG.restoreHotbarSlot && savedSlot >= 0 && savedSlot < 9) {
                client.player.getInventory().selectedSlot = savedSlot;
            }
            if (ClutchConfig.CONFIG.restoreCamera && phase != Phase.IDLE) {
                client.player.setYaw(savedYaw);
                client.player.setPitch(savedPitch);
            }
        }
        phase = Phase.IDLE;
        chosen = null;
        groundHit = null;
        savedSlot = -1;
        attemptCount = 0;
        rejectedTypes.clear();
    }

    private record PredictedTarget(BlockHitResult hit, double verticalDistance, double timeToImpactTicks) {}
}
