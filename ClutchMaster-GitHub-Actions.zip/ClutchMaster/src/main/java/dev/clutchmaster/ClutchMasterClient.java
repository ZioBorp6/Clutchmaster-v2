package dev.clutchmaster;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class ClutchMasterClient implements ClientModInitializer {
    public static final String MOD_ID = "clutchmaster";
    public static KeyBinding toggleKey;
    public static KeyBinding settingsKey;

    @Override
    public void onInitializeClient() {
        ClutchConfig.load();

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.clutchmaster.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "category.clutchmaster"
        ));
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.clutchmaster.settings",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                "category.clutchmaster"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                ClutchConfig.CONFIG.enabled = !ClutchConfig.CONFIG.enabled;
                ClutchConfig.save();
                ClutchController.onToggled(client, ClutchConfig.CONFIG.enabled);
                if (client.player != null) {
                    client.player.sendMessage(Text.translatable(
                            ClutchConfig.CONFIG.enabled ? "message.clutchmaster.enabled" : "message.clutchmaster.disabled"
                    ), true);
                }
            }

            while (settingsKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClutchSettingsScreen(null));
                }
            }
            ClutchController.tick(client);
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.options.hudHidden) return;
            int color = ClutchConfig.CONFIG.enabled ? 0x55FF55 : 0xAAAAAA;
            String label = "ClutchMaster: " + (ClutchConfig.CONFIG.enabled ? "ON" : "OFF");
            drawContext.drawTextWithShadow(client.textRenderer, label, 6, 6, color);
            String activity = ClutchController.getHudStatus();
            if (!activity.isEmpty()) {
                drawContext.drawTextWithShadow(client.textRenderer, activity, 6, 18, 0xFFFFFF);
            }
        });
    }
}
