# ClutchMaster 1.1.0 — Fabric 1.20.1

ClutchMaster is a client-side clutch-assistance mod for Minecraft Java 1.20.1. It uses standard Minecraft client interaction methods; the server remains authoritative and may reject an interaction.

## Features in 1.1.0

- Predictive fall tracking based on downward velocity and estimated time-to-impact.
- Predicts horizontal drift before choosing a landing block, rather than raycasting only beneath the player's current coordinates.
- Uses a collision-shape raycast and checks the top face and placement clearance.
- Smooth camera steering with configurable turn speed and early-aim distance.
- Scans the hotbar for enabled clutch items, following the configured priority.
- Water bucket, powder snow bucket, slime block, hay bale, cobweb, and boat/raft detection.
- Boat use is issued through the normal item-use interaction and requires camera aim because the vanilla boat item performs its own view raycast.
- Limited, spaced retries only when the local interaction result is not accepted.
- Restores the prior camera direction and hotbar slot after an attempt sequence (configurable hotbar restoration).
- In-game settings screen and HUD status indicator.
- Rebindable toggle and settings keys through Minecraft's normal Controls menu, which can be mapped to PojavLauncher on-screen keyboard buttons.

## Requirements

- Minecraft Java Edition 1.20.1
- Java 17
- Fabric Loader 0.15.x or newer
- Fabric API `0.92.2+1.20.1`

## Controls

Default keys:

- **G** — toggle Auto MLG
- **H** — open ClutchMaster settings

Both keys are registered in Minecraft's normal keybind list and can be rebound under **Options → Controls → Key Binds → ClutchMaster**. In PojavLauncher, edit the on-screen control layout and make the chosen virtual buttons send the same key as the Minecraft binding.

## Settings screen

Press **H** in a world or from the title screen. Settings include:

- Auto MLG on/off
- Automatic camera aim on/off
- Individual clutch type toggles
- Scan all nine hotbar slots or only the currently selected slot
- Restore the previous hotbar slot
- Camera aim speed (default 12 degrees per client tick)
- Fall detection sensitivity
- Distance at which camera aiming begins
- Cycle the clutch priority order

Settings are saved to `.minecraft/config/clutchmaster.json`.

## Build with GitHub Actions

The repository includes `.github/workflows/build.yml`. Push the project to GitHub, open **Actions**, and run **Build ClutchMaster**. Download the `ClutchMaster-build` artifact from the completed workflow. Use `clutchmaster-1.1.0.jar`, not the `-sources.jar`.

For a local build, run:

```bash
gradle --no-daemon clean build
```

The JAR is generated in `build/libs/`.

## Install

1. Install Fabric Loader for Minecraft 1.20.1.
2. Put Fabric API for 1.20.1 into the `mods` folder.
3. Put `clutchmaster-1.1.0.jar` into the same `mods` folder.
4. Launch the Fabric 1.20.1 profile.

## Accuracy notes and limitations

- The trajectory model is an approximation of Minecraft's tick physics. Movement effects, collisions, elytra, fluids, server latency, and unusual server rules can change the result.
- Local `ActionResult` acceptance does not guarantee that a remote server accepted or completed the clutch.
- Water and powder snow may be forbidden by the dimension, world rules, region protections, or server.
- Boat placement/use is especially situational and depends on vanilla item targeting and server behavior.
- Test in a single-player or other safe world before relying on it. No automated clutch can guarantee a successful landing in every situation.

## License

MIT
